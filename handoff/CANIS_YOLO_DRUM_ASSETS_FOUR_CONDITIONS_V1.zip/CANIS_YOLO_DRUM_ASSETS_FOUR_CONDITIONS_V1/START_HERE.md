# CANIS YOLO drum assets · four conditions · v1

1. Extract this ZIP. Open **warehouse-v3/CANIS_YOLO_FOUR_CONDITION.usda** in Isaac Sim 6.2.
2. Open **warehouse-v3/sample_catalog.json** for the 24 sample package IDs, prim paths, tiers and aisle viewing positions. Each condition has six examples, one per category and tier. Variants include yellow LLW and teal ILW, different rack positions and varied defect severity, rust texture and bulge shape.
3. Use **docs/warehouse_yolo_handoff.md** for capture and labeling guidance and the existing labeled LLW dataset. This ZIP is a portable USD asset pack with sample conditions. It contains no new rendered training images or YOLO boxes. The catalog is condition truth for asset selection and evaluation.
4. Keep the folder together so the USD layers and texture references resolve. For more visual variants, use the randomized session generator or the linked studio dataset recipe. Reserve whole scene seeds for validation and test when generating additional data.

**For the teammate's coding agent:** Give it this extracted folder and paste the complete **AGENT_TRAINING_PROMPT.md**. The prompt includes pilot acceptance criteria, label rules, split policy, training commands and delivery checks.
